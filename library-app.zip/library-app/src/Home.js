function Home()
{




    return(
        <div>
            <h1>HOme</h1>
        </div>
    );
}
export default Home;
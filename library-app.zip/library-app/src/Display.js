import { useEffect, useState } from "react";
import '../node_modules/bootstrap/dist/css/bootstrap.css';
function Display()
{
    const [patient,setPatient]=useState([]);
    const [message, setmessage] = useState("");

    useEffect(()=>{

        var helper=new XMLHttpRequest();
        helper.onreadystatechange=()=>{
            if(helper.readyState==4 && helper.status==200)
            {
             
                var result=JSON.parse(helper.responseText);
                console.log(result);
                debugger;
                setPatient(result);
            }
        };
        helper.open("GET","http://localhost:9999/patients");
        helper.send();


    },[])
    useEffect(()=>{
        if(message!="")
        {
            if(message == "Record Removed Successfully!")
            {
                //Refresh the set of employees
                var helper = new XMLHttpRequest();
                helper.onreadystatechange = ()=>{
                    if(helper.readyState == 4 && helper.status == 200)
                    {
                        var result = JSON.parse(helper.responseText);
                        setPatient(result);
                    }
                };
                helper.open("GET","http://localhost:9999/patients");
                helper.send();
            }
            setTimeout(() => 
            {
                setmessage("");
            }, 2000);
        }
    },[message])

    const removeRecord =(No)=>{
        var helper = new XMLHttpRequest();
        helper.onreadystatechange = ()=>
                {
                    if(helper.readyState == 4 && helper.status == 200)
                    {
                        var result = JSON.parse(helper.responseText);
                        if(result.affectedRows!=undefined)
                        {
                            if(result.affectedRows > 0)
                            {
                               // debugger;
                               setmessage("Record Removed Successfully!");
                            }
                            else
                            {
                               setmessage("We could not remove the record.!")
                            }
                        }
                        else
                        {
                            setmessage("Something went wrong! Try Again!"); 
                        }
                    }
                };
        helper.open("DELETE","http://localhost:9999/patients/" + No);
        helper.send();
    }
   
    const retrauntList = [
        {
"info": {
"id": "147547",
"name": "Panchatantra ki Laghu Kathayen",
"cloudinaryImageId": "https://m.media-amazon.com/images/I/51SYBhEtc4L._BG0,0,0,0_FMpng_AC_SY320_SX320_.jpg",
"locality": "Kothari Blocks",
"areaName": "Bibwewadi",
"costForTwo": "₹300 for two",
"cuisines": [
"South Indian"
],
"avgRating": 4.5,
"veg": true,
"feeDetails": {
"restaurantId": "147547",
"fees": [
{
"name": "BASE_DISTANCE",
"fee": 5200
},
{
"name": "BASE_TIME"
},
{
"name": "ANCILLARY_SURGE_FEE"
}
],
"totalFee": 5200
},
"parentId": "227837",
"avgRatingString": "4.5",
"totalRatingsString": "5K+",
"sla": {
"deliveryTime": 33,
"lastMileTravel": 5.5,
"serviceability": "SERVICEABLE",
"slaString": "33 mins",
"lastMileTravelString": "5.5 km",
"iconType": "ICON_TYPE_EMPTY"
},
"availability": {
"nextCloseTime": "2023-08-21 22:00:00",
"opened": true
},
"badges": {},
"isOpen": true,
"type": "F",
"badgesV2": {
"entityBadges": {
"imageBased": {},
"textBased": {},
"textExtendedBadges": {}
}
},
"aggregatedDiscountInfoV3": {
"discountCalloutInfo": {
"message": "Free Delivery",
"logoCtx": {
"logo": "v1655895371/free_delivery_logo_hqipbo.png"
}
}
},
"orderabilityCommunication": {
"title": {},
"subTitle": {},
"message": {},
"customIcon": {}
},
"differentiatedUi": {
"displayType": "ADS_UI_DISPLAY_TYPE_ENUM_DEFAULT",
"differentiatedUiMediaDetails": {
"mediaType": "ADS_MEDIA_ENUM_IMAGE",
"lottie": {},
"video": {}
}
},
"reviewsSummary": {},
"displayType": "RESTAURANT_DISPLAY_TYPE_DEFAULT",
"restaurantOfferPresentationInfo": {}
},
"analytics": {},
"cta": {
"link": "https://www.swiggy.com/restaurants/yenna-dosa-kothari-blocks-bibwewadi-pune-147547",
"type": "WEBLINK"
}
},
{
"info": {
"id": "5107",
"name": "Akbar Aur Birbal Ki Rochak Kathayen",
"cloudinaryImageId": "https://m.media-amazon.com/images/I/61t6JvN8XXL._SX347_BO1,204,203,200_.jpg",
"locality": "Bund Garden Road",
"areaName": "Camp Area",
"costForTwo": "₹700 for two",
"cuisines": [
"Indian",
"Chinese"
],
"avgRating": 4.1,
"feeDetails": {
"restaurantId": "5107",
"fees": [
{
"name": "BASE_DISTANCE",
"fee": 4500
},
{
"name": "BASE_TIME"
},
{
"name": "ANCILLARY_SURGE_FEE"
}
],
"totalFee": 4500
},
"parentId": "145",
"avgRatingString": "4.1",
"totalRatingsString": "10K+",
"sla": {
"deliveryTime": 21,
"lastMileTravel": 3,
"serviceability": "SERVICEABLE",
"slaString": "21 mins",
"lastMileTravelString": "3.0 km",
"iconType": "ICON_TYPE_EMPTY"
},
"availability": {
"nextCloseTime": "2023-08-21 23:00:00",
"opened": true
},
"badges": {},
"isOpen": true,
"type": "F",
"badgesV2": {
"entityBadges": {
"imageBased": {},
"textBased": {},
"textExtendedBadges": {}
}
},
"aggregatedDiscountInfoV3": {
"header": "60% OFF",
"subHeader": "UPTO ₹120",
"discountCalloutInfo": {
"message": "Free Delivery",
"logoCtx": {
"logo": "v1655895371/free_delivery_logo_hqipbo.png"
}
}
},
"orderabilityCommunication": {
"title": {},
"subTitle": {},
"message": {},
"customIcon": {}
},
"differentiatedUi": {
"displayType": "ADS_UI_DISPLAY_TYPE_ENUM_DEFAULT",
"differentiatedUiMediaDetails": {
"mediaType": "ADS_MEDIA_ENUM_IMAGE",
"lottie": {},
"video": {}
}
},
"reviewsSummary": {},
"displayType": "RESTAURANT_DISPLAY_TYPE_DEFAULT",
"restaurantOfferPresentationInfo": {}
},
"analytics": {},
"cta": {
"link": "https://www.swiggy.com/restaurants/blue-nile-bund-garden-road-camp-area-pune-5107",
"type": "WEBLINK"
}
},
{
"info": {
"id": "13907",
"name": "The Illustrated Stories Of Tenali Raman",
"cloudinaryImageId": "https://m.media-amazon.com/images/I/61MzrSdwJfL._SX321_BO1,204,203,200_.jpg",
"locality": "Law College Road",
"areaName": "Kothrud",
"costForTwo": "₹350 for two",
"cuisines": [
"South Indian",
"Snacks",
"Street Food",
"Beverages",
"Desserts"
],
"avgRating": 4.5,
"feeDetails": {
"restaurantId": "13907",
"fees": [
{
"name": "BASE_DISTANCE",
"fee": 4000
},
{
"name": "BASE_TIME"
},
{
"name": "ANCILLARY_SURGE_FEE"
}
],
"totalFee": 4000
},
"parentId": "1770",
"avgRatingString": "4.5",
"totalRatingsString": "10K+",
"sla": {
"deliveryTime": 31,
"lastMileTravel": 3.7,
"serviceability": "SERVICEABLE",
"slaString": "31 mins",
"lastMileTravelString": "3.7 km",
"iconType": "ICON_TYPE_EMPTY"
},
"availability": {
"nextCloseTime": "2023-08-21 22:55:00",
"opened": true
},
"badges": {},
"isOpen": true,
"type": "F",
"badgesV2": {
"entityBadges": {
"imageBased": {},
"textBased": {},
"textExtendedBadges": {}
}
},
"aggregatedDiscountInfoV3": {
"discountCalloutInfo": {
"message": "Free Delivery",
"logoCtx": {
"logo": "v1655895371/free_delivery_logo_hqipbo.png"
}
}
},
"orderabilityCommunication": {
"title": {},
"subTitle": {},
"message": {},
"customIcon": {}
},
"differentiatedUi": {
"displayType": "ADS_UI_DISPLAY_TYPE_ENUM_DEFAULT",
"differentiatedUiMediaDetails": {
"mediaType": "ADS_MEDIA_ENUM_IMAGE",
"lottie": {},
"video": {}
}
},
"reviewsSummary": {},
"displayType": "RESTAURANT_DISPLAY_TYPE_DEFAULT",
"restaurantOfferPresentationInfo": {}
},
"analytics": {},
"cta": {
"link": "https://www.swiggy.com/restaurants/wadeshwar-law-college-road-law-college-road-kothrud-pune-13907",
"type": "WEBLINK"
}
},
{
"info": {
"id": "12050",
"name": "Subway",
"cloudinaryImageId": "1ace5fa65eff3e1223feb696c956b38b",
"locality": "MAHABALESHWAR HOTEL",
"areaName": "Baner",
"costForTwo": "₹350 for two",
"cuisines": [
"Healthy Food",
"Salads",
"Snacks",
"Desserts",
"Beverages"
],
"avgRating": 4.2,
"feeDetails": {
"restaurantId": "12050",
"fees": [
{
"name": "BASE_DISTANCE",
"fee": 6400
},
{
"name": "BASE_TIME"
},
{
"name": "ANCILLARY_SURGE_FEE"
}
],
"totalFee": 6400
},
"parentId": "2",
"avgRatingString": "4.2",
"totalRatingsString": "10K+",
"sla": {
"deliveryTime": 36,
"lastMileTravel": 7.9,
"serviceability": "SERVICEABLE",
"slaString": "36 mins",
"lastMileTravelString": "7.9 km",
"iconType": "ICON_TYPE_EMPTY"
},
"availability": {
"nextCloseTime": "2023-08-21 23:59:00",
"opened": true
},
"badges": {},
"isOpen": true,
"type": "F",
"badgesV2": {
"entityBadges": {
"imageBased": {},
"textBased": {},
"textExtendedBadges": {}
}
},
"aggregatedDiscountInfoV3": {
"header": "40% OFF",
"subHeader": "UPTO ₹80",
"discountCalloutInfo": {
"message": "Free Delivery",
"logoCtx": {
"logo": "v1655895371/free_delivery_logo_hqipbo.png"
}
}
},
"orderabilityCommunication": {
"title": {},
"subTitle": {},
"message": {},
"customIcon": {}
},
"differentiatedUi": {
"displayType": "ADS_UI_DISPLAY_TYPE_ENUM_DEFAULT",
"differentiatedUiMediaDetails": {
"mediaType": "ADS_MEDIA_ENUM_IMAGE",
"lottie": {},
"video": {}
}
},
"reviewsSummary": {},
"displayType": "RESTAURANT_DISPLAY_TYPE_DEFAULT",
"restaurantOfferPresentationInfo": {}
},
"analytics": {},
"cta": {
"link": "https://www.swiggy.com/restaurants/subway-mahabaleshwar-hotel-baner-pune-12050",
"type": "WEBLINK"
}
},
{
"info": {
"id": "200980",
"name": "Irani Cafe",
"cloudinaryImageId": "lwysdaf2bdkz40mqtjbr",
"locality": "Prabhat Road",
"areaName": "Erandwane",
"costForTwo": "₹200 for two",
"cuisines": [
"Bakery",
"Snacks",
"Fast Food",
"Desserts",
"Beverages",
"Indian",
"Street Food"
],
"avgRating": 4.4,
"feeDetails": {
"restaurantId": "200980",
"fees": [
{
"name": "BASE_DISTANCE",
"fee": 3400
},
{
"name": "BASE_TIME"
},
{
"name": "ANCILLARY_SURGE_FEE"
}
],
"totalFee": 3400
},
"parentId": "4057",
"avgRatingString": "4.4",
"totalRatingsString": "10K+",
"sla": {
"deliveryTime": 19,
"lastMileTravel": 2.7,
"serviceability": "SERVICEABLE",
"slaString": "19 mins",
"lastMileTravelString": "2.7 km",
"iconType": "ICON_TYPE_EMPTY"
},
"availability": {
"nextCloseTime": "2023-08-21 23:45:00",
"opened": true
},
"badges": {},
"isOpen": true,
"type": "F",
"badgesV2": {
"entityBadges": {
"imageBased": {},
"textBased": {},
"textExtendedBadges": {}
}
},
"aggregatedDiscountInfoV3": {
"discountCalloutInfo": {
"message": "Free Delivery",
"logoCtx": {
"logo": "v1655895371/free_delivery_logo_hqipbo.png"
}
}
},
"orderabilityCommunication": {
"title": {},
"subTitle": {},
"message": {},
"customIcon": {}
},
"differentiatedUi": {
"displayType": "ADS_UI_DISPLAY_TYPE_ENUM_DEFAULT",
"differentiatedUiMediaDetails": {
"mediaType": "ADS_MEDIA_ENUM_IMAGE",
"lottie": {},
"video": {}
}
},
"reviewsSummary": {},
"displayType": "RESTAURANT_DISPLAY_TYPE_DEFAULT",
"restaurantOfferPresentationInfo": {}
},
"analytics": {},
"cta": {
"link": "https://www.swiggy.com/restaurants/irani-cafe-prabhat-road-erandwane-pune-200980",
"type": "WEBLINK"
}
},
{
"info": {
"id": "507946",
"name": "Paratha Box - Desi Punjabi Meals",
"cloudinaryImageId": "bde8bfbd9092b770b4b6fb05232f51e1",
"locality": "Ghole Road",
"areaName": "SHIVAJINAGAR",
"costForTwo": "₹250 for two",
"cuisines": [
"North Indian",
"Punjabi",
"Indian",
"Home Food",
"Beverages"
],
"avgRating": 3.7,
"feeDetails": {
"restaurantId": "507946",
"fees": [
{
"name": "BASE_DISTANCE",
"fee": 3400
},
{
"name": "BASE_TIME"
},
{
"name": "ANCILLARY_SURGE_FEE"
}
],
"totalFee": 3400
},
"parentId": "306004",
"avgRatingString": "3.7",
"totalRatingsString": "50+",
"sla": {
"deliveryTime": 25,
"lastMileTravel": 1.4,
"serviceability": "SERVICEABLE",
"slaString": "25 mins",
"lastMileTravelString": "1.4 km",
"iconType": "ICON_TYPE_EMPTY"
},
"availability": {
"nextCloseTime": "2023-08-21 23:00:00",
"opened": true
},
"badges": {},
"isOpen": true,
"type": "F",
"badgesV2": {
"entityBadges": {
"imageBased": {},
"textBased": {},
"textExtendedBadges": {}
}
},
"aggregatedDiscountInfoV3": {
"header": "₹125 OFF",
"subHeader": "ABOVE ₹399",
"discountTag": "FLAT DEAL",
"discountCalloutInfo": {
"message": "Free Delivery",
"logoCtx": {
"logo": "v1655895371/free_delivery_logo_hqipbo.png"
}
}
},
"orderabilityCommunication": {
"title": {},
"subTitle": {},
"message": {},
"customIcon": {}
},
"differentiatedUi": {
"displayType": "ADS_UI_DISPLAY_TYPE_ENUM_DEFAULT",
"differentiatedUiMediaDetails": {
"mediaType": "ADS_MEDIA_ENUM_IMAGE",
"lottie": {},
"video": {}
}
},
"reviewsSummary": {},
"displayType": "RESTAURANT_DISPLAY_TYPE_DEFAULT",
"restaurantOfferPresentationInfo": {}
},
"analytics": {},
"cta": {
"link": "https://www.swiggy.com/restaurants/paratha-box-desi-punjabi-meals-ghole-road-shivajinagar-pune-507946",
"type": "WEBLINK"
}
},
{
"info": {
"id": "507940",
"name": "EatFit",
"cloudinaryImageId": "6126c9b45de2cb222405c1af8a321e74",
"locality": "Ghole Road",
"areaName": "Shivajinagar",
"costForTwo": "₹270 for two",
"cuisines": [
"Chinese",
"Healthy Food",
"Tandoor",
"Pizzas",
"North Indian",
"Thalis",
"Biryani"
],
"avgRating": 4.1,
"feeDetails": {
"restaurantId": "507940",
"fees": [
{
"name": "BASE_DISTANCE",
"fee": 3400
},
{
"name": "BASE_TIME"
},
{
"name": "ANCILLARY_SURGE_FEE"
}
],
"totalFee": 3400
},
"parentId": "76139",
"avgRatingString": "4.1",
"totalRatingsString": "1K+",
"sla": {
"deliveryTime": 18,
"lastMileTravel": 1.4,
"serviceability": "SERVICEABLE",
"slaString": "18 mins",
"lastMileTravelString": "1.4 km",
"iconType": "ICON_TYPE_EMPTY"
},
"availability": {
"nextCloseTime": "2023-08-21 23:30:00",
"opened": true
},
"badges": {},
"isOpen": true,
"type": "F",
"badgesV2": {
"entityBadges": {
"imageBased": {},
"textBased": {},
"textExtendedBadges": {}
}
},
"aggregatedDiscountInfoV3": {
"header": "₹125 OFF",
"subHeader": "ABOVE ₹249",
"discountTag": "FLAT DEAL",
"discountCalloutInfo": {
"message": "Free Delivery",
"logoCtx": {
"logo": "v1655895371/free_delivery_logo_hqipbo.png"
}
}
},
"orderabilityCommunication": {
"title": {},
"subTitle": {},
"message": {},
"customIcon": {}
},
"differentiatedUi": {
"displayType": "ADS_UI_DISPLAY_TYPE_ENUM_DEFAULT",
"differentiatedUiMediaDetails": {
"mediaType": "ADS_MEDIA_ENUM_IMAGE",
"lottie": {},
"video": {}
}
},
"reviewsSummary": {},
"displayType": "RESTAURANT_DISPLAY_TYPE_DEFAULT",
"restaurantOfferPresentationInfo": {}
},
"analytics": {},
"cta": {
"link": "https://www.swiggy.com/restaurants/eatfit-ghole-road-shivajinagar-pune-507940",
"type": "WEBLINK"
}
},
{
"info": {
"id": "288388",
"name": "Starbucks Coffee",
"cloudinaryImageId": "4df3497f1460dfd1ecd8125222f6d362",
"locality": "FC Road",
"areaName": "Shivajinagar",
"costForTwo": "₹400 for two",
"cuisines": [
"Beverages",
"Cafe",
"Snacks",
"Desserts",
"Bakery",
"Ice Cream"
],
"avgRating": 4.3,
"feeDetails": {
"restaurantId": "288388",
"fees": [
{
"name": "BASE_DISTANCE",
"fee": 3400
},
{
"name": "BASE_TIME"
},
{
"name": "ANCILLARY_SURGE_FEE"
}
],
"totalFee": 3400
},
"parentId": "195515",
"avgRatingString": "4.3",
"totalRatingsString": "1K+",
"sla": {
"deliveryTime": 21,
"lastMileTravel": 2,
"serviceability": "SERVICEABLE",
"slaString": "21 mins",
"lastMileTravelString": "2.0 km",
"iconType": "ICON_TYPE_EMPTY"
},
"availability": {
"nextCloseTime": "2023-08-21 23:00:00",
"opened": true
},
"badges": {},
"isOpen": true,
"type": "F",
"badgesV2": {
"entityBadges": {
"imageBased": {},
"textBased": {},
"textExtendedBadges": {}
}
},
"aggregatedDiscountInfoV3": {
"header": "10% OFF",
"subHeader": "ABOVE ₹700",
"discountTag": "FLAT DEAL",
"discountCalloutInfo": {
"message": "Free Delivery",
"logoCtx": {
"logo": "v1655895371/free_delivery_logo_hqipbo.png"
}
}
},
"orderabilityCommunication": {
"title": {},
"subTitle": {},
"message": {},
"customIcon": {}
},
"differentiatedUi": {
"displayType": "ADS_UI_DISPLAY_TYPE_ENUM_DEFAULT",
"differentiatedUiMediaDetails": {
"mediaType": "ADS_MEDIA_ENUM_IMAGE",
"lottie": {},
"video": {}
}
},
"reviewsSummary": {},
"displayType": "RESTAURANT_DISPLAY_TYPE_DEFAULT",
"restaurantOfferPresentationInfo": {}
},
"analytics": {},
"cta": {
"link": "https://www.swiggy.com/restaurants/starbucks-coffee-fc-road-shivajinagar-pune-288388",
"type": "WEBLINK"
}
},

    ];

const RestrauntCard = ({name,cuisines,avgRating,cloudinaryImageId}) =>{ 
    return(
        <div className="card">
            <img src={cloudinaryImageId}/>
            {/* <h2>{name}</h2> */}
            {/* <h3>{cuisines.slice(0,3).join(",")}</h3> */}
            {/* <h4>{avgRating}, stars</h4> */}
        </div>
    )
}

const Body = () => {
    return(
        <div className="restraunt-list">
            {retrauntList.map((retraunt)=>{
                return <RestrauntCard
                {...retraunt.info} key = {retraunt.info.id}/>
            })}
        </div>
    );
}
    

    return(
        <>
        <Body/>
        </>
    );
//         <div>
//             <span style={{color: "orange"}}>{message}</span>
//               <div  className="table-responsive marginset">
//         <center>
//             <h5><u>Display</u></h5>
//         <table className="table">
//          <thead>
//         <tr>
//           <th scope="col">SNo.</th>
//           <th scope="col">Book Name</th>
//           <th scope="col">Book Author</th>
//           <th scope="col">Book Price</th>
//           <th scope="col">Book Category</th>
//           <th scope="col">Book Img</th>
//     </tr>
//   </thead>
//             <tbody>
//                 {
//                     patient.map((pat)=>{
//                         return<tr key={pat.id}>
//                             <td>{pat.id}</td>
//                             <td>{pat.name}</td>
//                             <td>{pat.email}</td>
//                             <td>{pat.password}</td>
//                             <td>{pat.phone}</td>
//                             <td>
//                                 <button className="btn btn-danger" onClick={()=>{removeRecord(pat.id);}}>Delete</button>
//                             </td>
//                         </tr>
//                     })
//                 }
//             </tbody>
//         </table>
//         </center>
//        </div>

//         </div>


}
export default Display;
/* const express = require('express');
const db = require("../db")
const utils = require("../utils")

const router = express.Router()

//InProgress
//need to create insert book count
//idk is it worth or not
//no need
router.post("/insert-book-copies", (request, response) => {

  const { available_copies } = request.body;
  const updateQuery = `
      INSERT INTO Books(available_copies) VALUES(?); 
    `;
  const updateBookCopyCountQuery = `
      INSERT INTO Book_Copy_Count(available_copies) VALUES(?);
    `;

  db.query(updateQuery, [available_copies], (error, result) => {
    if (error) {
      console.error(error);
      db.end;
      response.send(utils.createResult(error, null))
    } else {

      db.query(updateBookCopyCountQuery, [available_copies], (error, result) => {
        db.end;

        if (error) {
          console.error(error);
          response.send(utils.createResult(error, null))
        }

        response.send(utils.createResult(null, result))
      });
    }
  });
});


//check the api
//OK
//to update the copy of books
//literelly no need
router.put("/update-book-copies", (request, response) => {

  const { book_id, available_copies } = request.body;
  const updateQuery = `
      UPDATE Books
      SET available_copies = ?
      WHERE idBooks = ?;
    `;
  const updateBookCopyCountQuery = `
      UPDATE Book_Copy_Count
      SET available_copies = ?
      WHERE book_id = ?;
    `;

  db.query(updateQuery, [available_copies, book_id], (error, result) => {
    if (error) {
      console.error(error);
      db.end;
      response.send(utils.createResult(error, null))
    } else {

      db.query(updateBookCopyCountQuery, [available_copies, book_id], (error, result) => {
        db.end;

        if (error) {
          console.error(error);
          response.send(utils.createResult(error, null))
        }

        response.send(utils.createResult(null, result))
      });
    }
  });
}); 



//to get the availaibility of books
router.get("/available-Book-count/:idBooks", (request, response) => {
  const idBooks = request.params.idBooks
  const statement = `SELECT available_copies FROM Books WHERE idBooks=?`
  db.query(statement, [idBooks], (error, result) => {
    response.send(utils.createResult(error, result))
  })
})



//when the user borrowed the book it will decrement the count of particular book copy
/* router.put("/copy-count-decrement/:book_id", (request, response) => {
  const book_id = request.params.book_id
  //const { available_copies } = request.body
  const borrowedQuery = "UPDATE Book_Copy_Count SET available_copies = available_copies - 1 WHERE book_id = ?;"
  const updateBookCopyCountQueryAgain = "UPDATE Books SET available_copies = available_copies - 1 WHERE idBooks = ?;"


  db.query(borrowedQuery, [book_id], (error, result) => {
    if (error) {
      db.end
      response.send(utils.createResult(error, null))
    } else {

      db.query(updateBookCopyCountQueryAgain, [book_id], (error, result) => {
        db.end

        if (error) {
          response.send(utils.createResult(error, null))
        } else {
          response.send(utils.createResult(null, result))
        }
      })
    }
  })
}) */


/*

//when the user returened the book it will increment the count of particular book copy
router.put("/copy-count-increment/:book_id", (request, response) => {
  const book_id = request.params.book_id
  //const { available_copies } = request.body
  const borrowedQuery = "UPDATE Book_Copy_Count SET available_copies = available_copies + 1 WHERE book_id = ?;"
  const updateBookCopyCountQueryAgain = "UPDATE Books SET available_copies = available_copies + 1 WHERE idBooks = ?;"


  db.query(borrowedQuery, [book_id], (error, result) => {
    if (error) {
      db.end
      response.send(utils.createResult(error, null))
    } else {

      db.query(updateBookCopyCountQueryAgain, [book_id], (error, result) => {
        db.end

        if (error) {
          response.send(utils.createResult(error, null))
        } else {
          response.send(utils.createResult(null, result))
        }
      })
    }
  })
})


module.exports = router 
 */
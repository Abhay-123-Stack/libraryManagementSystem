import React,{ useState } from "react";
import Button from "./Button";
import CounterComponent from "./counterComponent";

function App() {
  
  const [components, setComponents ] = useState([""]);
    
    function addComponent () {

      setComponents([...components,"CounterComponent"])
    }

    return (
      <div>
        <Button onClick={addComponent} text = "More"/>
        {components.map((item,i)=>(<CounterComponent text={item} key={i}/>))}
      </div>
    )

  };

  export default App;


